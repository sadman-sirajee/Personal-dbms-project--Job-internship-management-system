<?php
/**
 * Job/Internship Management - Update / Edit Listing
 * Job/Internship Management System
 */
require_once __DIR__ . '/../config/database.php';
require_admin();

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) {
    set_flash('danger', 'Invalid listing ID.');
    header("Location: " . base_url('jobs/index.php'));
    exit;
}

// Fetch listing
$stmt = $pdo->prepare("SELECT * FROM jobs WHERE id = ? LIMIT 1");
$stmt->execute([$id]);
$listing = $stmt->fetch();

if (!$listing) {
    set_flash('danger', 'Listing not found.');
    header("Location: " . base_url('jobs/index.php'));
    exit;
}

$errors = [];
$title = $listing['title'];
$company = $listing['company'];
$location = $listing['location'];
$type = $listing['type'];
$description = $listing['description'];
$deadline = $listing['deadline'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $company = trim($_POST['company'] ?? '');
    $location = trim($_POST['location'] ?? '');
    $type = trim($_POST['type'] ?? 'Job');
    $description = trim($_POST['description'] ?? '');
    $deadline = trim($_POST['deadline'] ?? '');

    // Form Validation
    if (empty($title)) {
        $errors[] = "Job/Internship Title is required.";
    } elseif (strlen($title) > 150) {
        $errors[] = "Title cannot exceed 150 characters.";
    }

    if (empty($company)) {
        $errors[] = "Company Name is required.";
    } elseif (strlen($company) > 150) {
        $errors[] = "Company name cannot exceed 150 characters.";
    }

    if (!in_array($type, ['Job', 'Internship'])) {
        $errors[] = "Invalid listing type. Must be either 'Job' or 'Internship'.";
    }

    if (!empty($deadline)) {
        $d = DateTime::createFromFormat('Y-m-d', $deadline);
        if (!$d || $d->format('Y-m-d') !== $deadline) {
            $errors[] = "Invalid deadline date format.";
        }
    } else {
        $deadline = null;
    }

    // Save changes
    if (empty($errors)) {
        try {
            $updateStmt = $pdo->prepare("UPDATE jobs SET title = ?, company = ?, location = ?, type = ?, description = ?, deadline = ? WHERE id = ?");
            $updateStmt->execute([$title, $company, $location, $type, $description, $deadline, $id]);

            set_flash('success', "Listing '{$title}' was successfully updated!");
            header("Location: " . base_url('jobs/index.php'));
            exit;
        } catch (PDOException $e) {
            $errors[] = "Database update error: " . htmlspecialchars($e->getMessage());
        }
    }
}

$page_title = "Edit Listing - #" . $listing['id'];
include_once __DIR__ . '/../includes/header.php';
?>

<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <!-- Breadcrumb / Back button -->
            <div class="mb-3">
                <a href="<?= base_url('jobs/index.php') ?>" class="text-decoration-none text-muted">
                    <i class="bi bi-arrow-left me-1"></i> Back to All Listings
                </a>
            </div>

            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-header bg-white border-bottom py-3">
                    <div class="d-flex align-items-center justify-content-between">
                        <h4 class="fw-bold mb-0 text-dark">
                            <i class="bi bi-pencil-square text-warning me-2"></i>Edit Listing: <?= htmlspecialchars($listing['title']) ?>
                        </h4>
                        <span class="badge bg-warning-subtle text-warning">CRUD: UPDATE</span>
                    </div>
                </div>
                <div class="card-body p-4">
                    <?php if (!empty($errors)): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <h6 class="fw-bold mb-1"><i class="bi bi-exclamation-triangle-fill me-1"></i> Please correct the following errors:</h6>
                            <ul class="mb-0 ps-3">
                                <?php foreach ($errors as $err): ?>
                                    <li><?= htmlspecialchars($err) ?></li>
                                <?php endforeach; ?>
                            </ul>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <form action="<?= base_url('jobs/edit.php?id=' . $id) ?>" method="POST">
                        <div class="row g-3">
                            <!-- Job Title -->
                            <div class="col-md-12">
                                <label for="title" class="form-label">Position Title <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="title" name="title" 
                                       value="<?= htmlspecialchars($title) ?>" required>
                            </div>

                            <!-- Company -->
                            <div class="col-md-6">
                                <label for="company" class="form-label">Company / Organization <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="company" name="company" 
                                       value="<?= htmlspecialchars($company) ?>" required>
                            </div>

                            <!-- Location -->
                            <div class="col-md-6">
                                <label for="location" class="form-label">Location</label>
                                <input type="text" class="form-control" id="location" name="location" 
                                       value="<?= htmlspecialchars($location ?? '') ?>">
                            </div>

                            <!-- Listing Type -->
                            <div class="col-md-6">
                                <label for="type" class="form-label">Listing Type <span class="text-danger">*</span></label>
                                <select class="form-select" id="type" name="type" required>
                                    <option value="Job" <?= ($type === 'Job') ? 'selected' : '' ?>>Job</option>
                                    <option value="Internship" <?= ($type === 'Internship') ? 'selected' : '' ?>>Internship</option>
                                </select>
                            </div>

                            <!-- Application Deadline -->
                            <div class="col-md-6">
                                <label for="deadline" class="form-label">Application Deadline</label>
                                <input type="date" class="form-control" id="deadline" name="deadline" 
                                       value="<?= htmlspecialchars($deadline ?? '') ?>">
                            </div>

                            <!-- Job Description -->
                            <div class="col-md-12">
                                <label for="description" class="form-label">Description &amp; Requirements</label>
                                <textarea class="form-control" id="description" name="description" rows="6"><?= htmlspecialchars($description ?? '') ?></textarea>
                            </div>
                        </div>

                        <!-- Action Buttons -->
                        <div class="d-flex justify-content-between align-items-center pt-4 mt-3 border-top">
                            <a href="<?= base_url('jobs/index.php') ?>" class="btn btn-outline-secondary">
                                <i class="bi bi-x-circle me-1"></i> Cancel
                            </a>
                            <button type="submit" class="btn btn-warning px-4 text-dark fw-semibold">
                                <i class="bi bi-save me-1"></i> Update Listing
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include_once __DIR__ . '/../includes/footer.php'; ?>
