<?php
/**
 * Job/Internship Management - Create Listing
 * Job/Internship Management System
 */
require_once __DIR__ . '/../config/database.php';
require_admin();

$errors = [];
$title = '';
$company = '';
$location = '';
$type = 'Job';
$description = '';
$deadline = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $company = trim($_POST['company'] ?? '');
    $location = trim($_POST['location'] ?? '');
    $type = trim($_POST['type'] ?? 'Job');
    $description = trim($_POST['description'] ?? '');
    $deadline = trim($_POST['deadline'] ?? '');

    // Form Validation
    if (empty($title)) {
        $errors[] = "Job/Internship Title is required.";
    } elseif (strlen($title) > 150) {
        $errors[] = "Title cannot exceed 150 characters.";
    }

    if (empty($company)) {
        $errors[] = "Company Name is required.";
    } elseif (strlen($company) > 150) {
        $errors[] = "Company name cannot exceed 150 characters.";
    }

    if (!in_array($type, ['Job', 'Internship'])) {
        $errors[] = "Invalid listing type. Must be either 'Job' or 'Internship'.";
    }

    if (!empty($deadline)) {
        // Validate date format YYYY-MM-DD
        $d = DateTime::createFromFormat('Y-m-d', $deadline);
        if (!$d || $d->format('Y-m-d') !== $deadline) {
            $errors[] = "Invalid deadline date format.";
        }
    } else {
        $deadline = null;
    }

    // Insert into database if validation passes
    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO jobs (title, company, location, type, description, deadline) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$title, $company, $location, $type, $description, $deadline]);

            set_flash('success', "Listing '{$title}' ({$type}) was successfully published!");
            header("Location: " . base_url('jobs/index.php'));
            exit;
        } catch (PDOException $e) {
            $errors[] = "Database insert error: " . htmlspecialchars($e->getMessage());
        }
    }
}

$page_title = "Add Job or Internship";
include_once __DIR__ . '/../includes/header.php';
?>

<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <!-- Breadcrumb / Back navigation -->
            <div class="mb-3">
                <a href="<?= base_url('jobs/index.php') ?>" class="text-decoration-none text-muted">
                    <i class="bi bi-arrow-left me-1"></i> Back to All Listings
                </a>
            </div>

            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-header bg-white border-bottom py-3">
                    <div class="d-flex align-items-center justify-content-between">
                        <h4 class="fw-bold mb-0 text-dark">
                            <i class="bi bi-plus-circle text-primary me-2"></i>Add New Job / Internship Listing
                        </h4>
                        <span class="badge bg-primary-subtle text-primary">CRUD: CREATE</span>
                    </div>
                </div>
                <div class="card-body p-4">
                    <?php if (!empty($errors)): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <h6 class="fw-bold mb-1"><i class="bi bi-exclamation-triangle-fill me-1"></i> Please correct the following errors:</h6>
                            <ul class="mb-0 ps-3">
                                <?php foreach ($errors as $err): ?>
                                    <li><?= htmlspecialchars($err) ?></li>
                                <?php endforeach; ?>
                            </ul>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <form action="<?= base_url('jobs/create.php') ?>" method="POST">
                        <div class="row g-3">
                            <!-- Job Title -->
                            <div class="col-md-12">
                                <label for="title" class="form-label">Position Title <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="title" name="title" 
                                       value="<?= htmlspecialchars($title) ?>" placeholder="e.g. Full Stack Developer, Machine Learning Intern" required>
                            </div>

                            <!-- Company -->
                            <div class="col-md-6">
                                <label for="company" class="form-label">Company / Organization <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="company" name="company" 
                                       value="<?= htmlspecialchars($company) ?>" placeholder="e.g. ABC Ltd, Google, Tech BD" required>
                            </div>

                            <!-- Location -->
                            <div class="col-md-6">
                                <label for="location" class="form-label">Location</label>
                                <input type="text" class="form-control" id="location" name="location" 
                                       value="<?= htmlspecialchars($location) ?>" placeholder="e.g. Dhaka, Remote, Chittagong">
                            </div>

                            <!-- Listing Type -->
                            <div class="col-md-6">
                                <label for="type" class="form-label">Listing Type <span class="text-danger">*</span></label>
                                <select class="form-select" id="type" name="type" required>
                                    <option value="Job" <?= ($type === 'Job') ? 'selected' : '' ?>>Job</option>
                                    <option value="Internship" <?= ($type === 'Internship') ? 'selected' : '' ?>>Internship</option>
                                </select>
                                <div class="form-text">Choose whether this opportunity is a full-time/part-time job or an internship.</div>
                            </div>

                            <!-- Application Deadline -->
                            <div class="col-md-6">
                                <label for="deadline" class="form-label">Application Deadline</label>
                                <input type="date" class="form-control" id="deadline" name="deadline" 
                                       value="<?= htmlspecialchars($deadline ?? '') ?>">
                                <div class="form-text">Last date for candidate submissions.</div>
                            </div>

                            <!-- Job Description -->
                            <div class="col-md-12">
                                <label for="description" class="form-label">Description &amp; Requirements</label>
                                <textarea class="form-control" id="description" name="description" rows="5" 
                                          placeholder="Detail the role responsibilities, required qualifications, skills, and compensation..."><?= htmlspecialchars($description) ?></textarea>
                            </div>
                        </div>

                        <!-- Action Buttons -->
                        <div class="d-flex justify-content-between align-items-center pt-4 mt-3 border-top">
                            <a href="<?= base_url('jobs/index.php') ?>" class="btn btn-outline-secondary">
                                <i class="bi bi-x-circle me-1"></i> Cancel
                            </a>
                            <button type="submit" class="btn btn-primary px-4">
                                <i class="bi bi-check-circle me-1"></i> Add Listing
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include_once __DIR__ . '/../includes/footer.php'; ?>
