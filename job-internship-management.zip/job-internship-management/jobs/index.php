<?php
/**
 * Job/Internship Management - Read, Search & Filter Listings
 * Job/Internship Management System
 */
require_once __DIR__ . '/../config/database.php';
require_login();

// Filters & Search parameters
$search = trim($_GET['search'] ?? '');
$typeFilter = trim($_GET['type'] ?? '');

// Build dynamic SQL query
$sql = "SELECT * FROM jobs WHERE 1=1";
$params = [];

if (!empty($search)) {
    $sql .= " AND (title LIKE ? OR company LIKE ? OR location LIKE ?)";
    $term = "%{$search}%";
    $params[] = $term;
    $params[] = $term;
    $params[] = $term;
}

if (!empty($typeFilter) && in_array($typeFilter, ['Job', 'Internship'])) {
    $sql .= " AND type = ?";
    $params[] = $typeFilter;
}

$sql .= " ORDER BY created_at DESC";

try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $listings = $stmt->fetchAll();

    $user = current_user();
    $isAdmin = is_admin();

    $userApplications = [];
    if (!$isAdmin && is_logged_in()) {
        $stmtUserApps = $pdo->prepare("SELECT job_id, status FROM applications WHERE user_id = ?");
        $stmtUserApps->execute([$user['id']]);
        $userApplications = $stmtUserApps->fetchAll(PDO::FETCH_KEY_PAIR);
    }

    $appCounts = [];
    if ($isAdmin) {
        $appCounts = $pdo->query("SELECT job_id, COUNT(*) FROM applications GROUP BY job_id")->fetchAll(PDO::FETCH_KEY_PAIR);
    }
} catch (PDOException $e) {
    die("Error fetching listings: " . htmlspecialchars($e->getMessage()));
}

$page_title = $isAdmin ? "Job & Internship Management" : "Explore Opportunities";
include_once __DIR__ . '/../includes/header.php';
?>

<div class="container py-4">
    <!-- Header Section -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 pb-2 border-bottom">
        <div>
            <h1 class="h2 fw-bold text-dark mb-1">
                <i class="bi <?= $isAdmin ? 'bi-briefcase-fill' : 'bi-search' ?> text-primary me-2"></i><?= $isAdmin ? 'Job &amp; Internship Management' : 'Explore Open Opportunities' ?>
            </h1>
            <p class="text-muted mb-0">
                <?= $isAdmin ? 'Browse, search, filter, publish, and manage all job and internship listings.' : 'Browse vacancies, filter by career track, and submit applications directly online.' ?>
            </p>
        </div>
        <div class="mt-3 mt-md-0 d-flex gap-2">
            <?php if ($isAdmin): ?>
                <a href="<?= base_url('jobs/create.php') ?>" class="btn btn-primary shadow-sm">
                    <i class="bi bi-plus-circle me-1"></i> Add New Listing
                </a>
            <?php else: ?>
                <a href="<?= base_url('applications/my_applications.php') ?>" class="btn btn-outline-primary shadow-sm">
                    <i class="bi bi-file-earmark-check me-1"></i> My Applications
                </a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Search & Filter Card -->
    <div class="card search-filter-card border-0 shadow-sm mb-4">
        <div class="card-body">
            <form method="GET" action="<?= base_url('jobs/index.php') ?>" class="row g-3">
                <!-- Search Input -->
                <div class="col-md-6 col-lg-5">
                    <label class="form-label small text-muted">Search Keyword</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light"><i class="bi bi-search"></i></span>
                        <input type="text" name="search" class="form-control" 
                               placeholder="Search title, company, or location..." 
                               value="<?= htmlspecialchars($search) ?>">
                    </div>
                </div>

                <!-- Type Filter -->
                <div class="col-md-4 col-lg-4">
                    <label class="form-label small text-muted">Filter By Listing Type</label>
                    <select name="type" class="form-select">
                        <option value="" <?= ($typeFilter === '') ? 'selected' : '' ?>>All Listings (Job &amp; Internship)</option>
                        <option value="Job" <?= ($typeFilter === 'Job') ? 'selected' : '' ?>>Job Postings Only</option>
                        <option value="Internship" <?= ($typeFilter === 'Internship') ? 'selected' : '' ?>>Internship Postings Only</option>
                    </select>
                </div>

                <!-- Action Buttons -->
                <div class="col-md-2 col-lg-3 d-flex align-items-end gap-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="bi bi-funnel-fill me-1"></i> Apply Filter
                    </button>
                    <?php if (!empty($search) || !empty($typeFilter)): ?>
                        <a href="<?= base_url('jobs/index.php') ?>" class="btn btn-outline-secondary" title="Reset Filters">
                            <i class="bi bi-arrow-counterclockwise"></i>
                        </a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>

    <!-- Active Filter Indicators -->
    <?php if (!empty($search) || !empty($typeFilter)): ?>
        <div class="d-flex align-items-center gap-2 mb-3">
            <span class="text-muted small">Active Filters:</span>
            <?php if (!empty($search)): ?>
                <span class="badge bg-light text-dark border">
                    Keyword: "<?= htmlspecialchars($search) ?>"
                </span>
            <?php endif; ?>
            <?php if (!empty($typeFilter)): ?>
                <span class="badge <?= ($typeFilter === 'Job') ? 'bg-primary' : 'bg-success' ?>">
                    Type: <?= htmlspecialchars($typeFilter) ?>
                </span>
            <?php endif; ?>
            <a href="<?= base_url('jobs/index.php') ?>" class="text-danger small text-decoration-none ms-2">
                <i class="bi bi-x-circle"></i> Clear All
            </a>
        </div>
    <?php endif; ?>

    <!-- Listings Table Card -->
    <div class="card border-0 shadow-sm">
        <div class="card-header bg-white d-flex justify-content-between align-items-center py-3">
            <h5 class="fw-bold mb-0 text-dark">
                <i class="bi bi-list-task text-primary me-2"></i>Listings (<?= count($listings) ?>)
            </h5>
            <div class="d-flex gap-2">
                <a href="<?= base_url('jobs/index.php') ?>" class="btn btn-sm <?= empty($typeFilter) ? 'btn-secondary' : 'btn-outline-secondary' ?>">All</a>
                <a href="<?= base_url('jobs/index.php?type=Job') ?>" class="btn btn-sm <?= ($typeFilter === 'Job') ? 'btn-primary' : 'btn-outline-primary' ?>">Jobs</a>
                <a href="<?= base_url('jobs/index.php?type=Internship') ?>" class="btn btn-sm <?= ($typeFilter === 'Internship') ? 'btn-success' : 'btn-outline-success' ?>">Internships</a>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                        <tr>
                            <th>Position Title</th>
                            <th>Hiring Company</th>
                            <th>Location</th>
                            <th>Type</th>
                            <th>Deadline</th>
                            <?php if ($isAdmin): ?>
                                <th>Applicants</th>
                            <?php endif; ?>
                            <th class="text-end" style="width: <?= $isAdmin ? '200px' : '180px' ?>;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($listings)): ?>
                            <?php foreach ($listings as $item): ?>
                                <tr>
                                    <td>
                                        <a href="<?= base_url('jobs/view.php?id=' . $item['id']) ?>" class="fw-bold text-dark text-decoration-none">
                                            <?= htmlspecialchars($item['title']) ?>
                                        </a>
                                        <div class="small text-muted d-block d-md-none"><?= htmlspecialchars($item['company']) ?></div>
                                    </td>
                                    <td>
                                        <span class="text-secondary fw-semibold">
                                            <i class="bi bi-building me-1"></i><?= htmlspecialchars($item['company']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <i class="bi bi-geo-alt text-muted me-1"></i><?= htmlspecialchars($item['location'] ?: 'Not Specified') ?>
                                    </td>
                                    <td>
                                        <span class="badge <?= ($item['type'] === 'Job') ? 'badge-type-job' : 'badge-type-internship' ?>">
                                            <?= htmlspecialchars($item['type']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if (!empty($item['deadline'])): ?>
                                            <?php 
                                            $isPast = strtotime($item['deadline']) < strtotime(date('Y-m-d'));
                                            ?>
                                            <span class="<?= $isPast ? 'text-danger fw-bold' : 'text-muted' ?>">
                                                <i class="bi bi-calendar3 me-1"></i><?= date('d-m-Y', strtotime($item['deadline'])) ?>
                                                <?php if ($isPast): ?>
                                                    <span class="badge bg-danger ms-1" style="font-size: 0.65rem;">Expired</span>
                                                <?php endif; ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="text-muted">No Deadline</span>
                                        <?php endif; ?>
                                    </td>
                                    <?php if ($isAdmin): ?>
                                        <td>
                                            <?php $count = $appCounts[$item['id']] ?? 0; ?>
                                            <a href="<?= base_url('applications/index.php?job_id=' . $item['id']) ?>" class="badge bg-light text-primary border text-decoration-none p-2" title="View applications for this position">
                                                <i class="bi bi-people me-1"></i> <?= $count ?> <?= $count === 1 ? 'Applicant' : 'Applicants' ?>
                                            </a>
                                        </td>
                                    <?php endif; ?>
                                    <td class="text-end">
                                        <?php if ($isAdmin): ?>
                                            <a href="<?= base_url('jobs/view.php?id=' . $item['id']) ?>" class="btn btn-outline-info btn-sm" title="View Listing Details">
                                                <i class="bi bi-eye"></i> View
                                            </a>
                                            <a href="<?= base_url('jobs/edit.php?id=' . $item['id']) ?>" class="btn btn-outline-warning btn-sm" title="Edit Listing">
                                                <i class="bi bi-pencil-square"></i> Edit
                                            </a>
                                            <a href="<?= base_url('jobs/delete.php?id=' . $item['id']) ?>" class="btn btn-outline-danger btn-sm" title="Delete Listing">
                                                <i class="bi bi-trash"></i> Delete
                                            </a>
                                        <?php else: ?>
                                            <?php if (isset($userApplications[$item['id']])): ?>
                                                <span class="badge bg-light text-success border me-1 py-2">
                                                    <i class="bi bi-check-circle-fill me-1"></i> Applied
                                                </span>
                                                <a href="<?= base_url('jobs/view.php?id=' . $item['id']) ?>" class="btn btn-outline-secondary btn-sm" title="View Details">
                                                    <i class="bi bi-eye"></i> View
                                                </a>
                                            <?php else: ?>
                                                <a href="<?= base_url('applications/apply.php?job_id=' . $item['id']) ?>" class="btn btn-primary btn-sm me-1 shadow-sm">
                                                    <i class="bi bi-send me-1"></i> Apply
                                                </a>
                                                <a href="<?= base_url('jobs/view.php?id=' . $item['id']) ?>" class="btn btn-outline-secondary btn-sm" title="View Details">
                                                    <i class="bi bi-eye"></i>
                                                </a>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="<?= $isAdmin ? 7 : 6 ?>" class="text-center py-5">
                                    <div class="text-muted">
                                        <i class="bi bi-folder-x display-4 d-block mb-2 text-secondary opacity-50"></i>
                                        No job or internship listings found.
                                    </div>
                                    <?php if ($isAdmin): ?>
                                        <a href="<?= base_url('jobs/create.php') ?>" class="btn btn-primary btn-sm mt-3">
                                            <i class="bi bi-plus-circle me-1"></i> Create First Listing
                                        </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include_once __DIR__ . '/../includes/footer.php'; ?>
