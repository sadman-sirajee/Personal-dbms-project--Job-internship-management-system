<?php
/**
 * Job/Internship Management - Delete Listing Confirmation & Action
 * Job/Internship Management System
 */
require_once __DIR__ . '/../config/database.php';
require_admin();

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?? filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
if (!$id) {
    set_flash('danger', 'Invalid listing ID.');
    header("Location: " . base_url('jobs/index.php'));
    exit;
}

// Fetch listing details
$stmt = $pdo->prepare("SELECT * FROM jobs WHERE id = ? LIMIT 1");
$stmt->execute([$id]);
$listing = $stmt->fetch();

if (!$listing) {
    set_flash('danger', 'Listing not found.');
    header("Location: " . base_url('jobs/index.php'));
    exit;
}

// Handle POST deletion confirmation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_delete'])) {
    try {
        $delStmt = $pdo->prepare("DELETE FROM jobs WHERE id = ?");
        $delStmt->execute([$id]);

        set_flash('success', "Listing '{$listing['title']}' has been permanently removed.");
        header("Location: " . base_url('jobs/index.php'));
        exit;
    } catch (PDOException $e) {
        set_flash('danger', "Error deleting listing: " . htmlspecialchars($e->getMessage()));
        header("Location: " . base_url('jobs/index.php'));
        exit;
    }
}

$page_title = "Delete Listing Confirmation";
include_once __DIR__ . '/../includes/header.php';
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-7 col-lg-6">
            <div class="card border-danger shadow-lg rounded-4 overflow-hidden">
                <div class="card-header bg-danger text-white py-3 text-center">
                    <i class="bi bi-exclamation-triangle-fill display-5 d-block mb-1"></i>
                    <h4 class="fw-bold mb-0">Confirm Listing Deletion</h4>
                    <span class="badge bg-danger-subtle text-white border border-light mt-1">CRUD: DELETE Operation</span>
                </div>
                <div class="card-body p-4 text-center">
                    <h5 class="text-danger fw-bold mb-3">
                        Are you sure you want to delete this listing?
                    </h5>
                    <p class="text-muted mb-4">
                        This action is irreversible. The posting will be permanently erased from the system database.
                    </p>

                    <!-- Listing Details Summary Box -->
                    <div class="bg-light p-3 rounded-3 text-start mb-4 border">
                        <div class="row mb-2">
                            <div class="col-4 text-muted fw-semibold">Title:</div>
                            <div class="col-8 fw-bold text-dark"><?= htmlspecialchars($listing['title']) ?></div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-4 text-muted fw-semibold">Company:</div>
                            <div class="col-8"><?= htmlspecialchars($listing['company']) ?></div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-4 text-muted fw-semibold">Location:</div>
                            <div class="col-8"><?= htmlspecialchars($listing['location'] ?: 'Not Specified') ?></div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-4 text-muted fw-semibold">Type:</div>
                            <div class="col-8">
                                <span class="badge <?= ($listing['type'] === 'Job') ? 'badge-type-job' : 'badge-type-internship' ?>">
                                    <?= htmlspecialchars($listing['type']) ?>
                                </span>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-4 text-muted fw-semibold">Deadline:</div>
                            <div class="col-8">
                                <?= !empty($listing['deadline']) ? date('d-m-Y', strtotime($listing['deadline'])) : 'N/A' ?>
                            </div>
                        </div>
                    </div>

                    <!-- Actions Form -->
                    <form action="<?= base_url('jobs/delete.php') ?>" method="POST" class="d-flex justify-content-center gap-3">
                        <input type="hidden" name="id" value="<?= $listing['id'] ?>">
                        <input type="hidden" name="confirm_delete" value="1">

                        <a href="<?= base_url('jobs/index.php') ?>" class="btn btn-outline-secondary px-4 py-2">
                            <i class="bi bi-x-circle me-1"></i> Cancel
                        </a>
                        <button type="submit" class="btn btn-danger px-4 py-2 fw-semibold shadow">
                            <i class="bi bi-trash-fill me-1"></i> Delete
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include_once __DIR__ . '/../includes/footer.php'; ?>
