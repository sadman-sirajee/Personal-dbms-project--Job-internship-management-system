<?php
/**
 * Admin Application Management
 * Job/Internship Management System
 */
require_once __DIR__ . '/../config/database.php';
require_admin();

// Handle status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'update_status') {
        $app_id = filter_input(INPUT_POST, 'application_id', FILTER_VALIDATE_INT);
        $new_status = trim($_POST['status'] ?? '');

        if ($app_id && in_array($new_status, ['Pending', 'Reviewed', 'Accepted', 'Rejected'])) {
            $stmt = $pdo->prepare("UPDATE applications SET status = ? WHERE id = ?");
            $stmt->execute([$new_status, $app_id]);
            set_flash('success', "Application #{$app_id} status updated to '{$new_status}'.");
        } else {
            set_flash('danger', "Invalid status update request.");
        }
    } elseif ($_POST['action'] === 'delete') {
        $app_id = filter_input(INPUT_POST, 'application_id', FILTER_VALIDATE_INT);
        if ($app_id) {
            $delStmt = $pdo->prepare("DELETE FROM applications WHERE id = ?");
            $delStmt->execute([$app_id]);
            set_flash('success', "Application #{$app_id} deleted successfully.");
        }
    }
    header("Location: " . base_url('applications/index.php'));
    exit;
}

// Search & Filter parameters
$search = trim($_GET['search'] ?? '');
$statusFilter = trim($_GET['status'] ?? '');
$jobFilter = filter_input(INPUT_GET, 'job_id', FILTER_VALIDATE_INT);

// Build query
$sql = "
    SELECT a.*, u.name AS applicant_name, u.email AS applicant_email,
           j.title AS job_title, j.company, j.type AS job_type
    FROM applications a
    JOIN users u ON a.user_id = u.id
    JOIN jobs j ON a.job_id = j.id
    WHERE 1=1
";
$params = [];

if (!empty($search)) {
    $sql .= " AND (u.name LIKE ? OR u.email LIKE ? OR j.title LIKE ? OR j.company LIKE ?)";
    $term = "%{$search}%";
    $params[] = $term;
    $params[] = $term;
    $params[] = $term;
    $params[] = $term;
}

if (!empty($statusFilter) && in_array($statusFilter, ['Pending', 'Reviewed', 'Accepted', 'Rejected'])) {
    $sql .= " AND a.status = ?";
    $params[] = $statusFilter;
}

if ($jobFilter) {
    $sql .= " AND a.job_id = ?";
    $params[] = $jobFilter;
}

$sql .= " ORDER BY a.applied_at DESC";

try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $applications = $stmt->fetchAll();

    // Metrics
    $totalCount = (int)$pdo->query("SELECT COUNT(*) FROM applications")->fetchColumn();
    $pendingCount = (int)$pdo->query("SELECT COUNT(*) FROM applications WHERE status = 'Pending'")->fetchColumn();
    $reviewedCount = (int)$pdo->query("SELECT COUNT(*) FROM applications WHERE status = 'Reviewed'")->fetchColumn();
    $acceptedCount = (int)$pdo->query("SELECT COUNT(*) FROM applications WHERE status = 'Accepted'")->fetchColumn();
    $rejectedCount = (int)$pdo->query("SELECT COUNT(*) FROM applications WHERE status = 'Rejected'")->fetchColumn();

    // Listings for filter dropdown
    $jobListings = $pdo->query("SELECT id, title, company FROM jobs ORDER BY title ASC")->fetchAll();
} catch (PDOException $e) {
    die("Database query error: " . htmlspecialchars($e->getMessage()));
}

$page_title = "Application Management - CareerPulse";
include_once __DIR__ . '/../includes/header.php';
?>

<div class="container py-4">
    <!-- Header Section -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 pb-2 border-bottom">
        <div>
            <h1 class="h2 fw-bold text-dark mb-1">
                <i class="bi bi-file-earmark-person-fill text-primary me-2"></i>Candidate Applications Management
            </h1>
            <p class="text-muted mb-0">Review candidate submissions, assess candidate pitches, and update application outcomes.</p>
        </div>
        <div class="mt-3 mt-md-0">
            <a href="<?= base_url('jobs/index.php') ?>" class="btn btn-outline-primary shadow-sm">
                <i class="bi bi-briefcase me-1"></i> Manage Job Postings
            </a>
        </div>
    </div>

    <!-- Status Metric Cards -->
    <div class="row g-3 mb-4">
        <div class="col-6 col-md">
            <a href="<?= base_url('applications/index.php') ?>" class="text-decoration-none">
                <div class="card border-0 shadow-sm rounded-3 bg-white <?= empty($statusFilter) ? 'border-primary border-2' : '' ?>">
                    <div class="card-body p-3 text-center">
                        <div class="text-muted small fw-semibold text-uppercase">Total Submissions</div>
                        <div class="h3 fw-bold text-dark mb-0"><?= $totalCount ?></div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-6 col-md">
            <a href="<?= base_url('applications/index.php?status=Pending') ?>" class="text-decoration-none">
                <div class="card border-0 shadow-sm rounded-3 bg-white <?= $statusFilter === 'Pending' ? 'border-warning border-2' : '' ?>">
                    <div class="card-body p-3 text-center">
                        <div class="text-muted small fw-semibold text-uppercase">Pending</div>
                        <div class="h3 fw-bold text-warning mb-0"><?= $pendingCount ?></div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-6 col-md">
            <a href="<?= base_url('applications/index.php?status=Reviewed') ?>" class="text-decoration-none">
                <div class="card border-0 shadow-sm rounded-3 bg-white <?= $statusFilter === 'Reviewed' ? 'border-info border-2' : '' ?>">
                    <div class="card-body p-3 text-center">
                        <div class="text-muted small fw-semibold text-uppercase">Under Review</div>
                        <div class="h3 fw-bold text-info mb-0"><?= $reviewedCount ?></div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-6 col-md">
            <a href="<?= base_url('applications/index.php?status=Accepted') ?>" class="text-decoration-none">
                <div class="card border-0 shadow-sm rounded-3 bg-white <?= $statusFilter === 'Accepted' ? 'border-success border-2' : '' ?>">
                    <div class="card-body p-3 text-center">
                        <div class="text-muted small fw-semibold text-uppercase">Accepted</div>
                        <div class="h3 fw-bold text-success mb-0"><?= $acceptedCount ?></div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-6 col-md">
            <a href="<?= base_url('applications/index.php?status=Rejected') ?>" class="text-decoration-none">
                <div class="card border-0 shadow-sm rounded-3 bg-white <?= $statusFilter === 'Rejected' ? 'border-danger border-2' : '' ?>">
                    <div class="card-body p-3 text-center">
                        <div class="text-muted small fw-semibold text-uppercase">Rejected</div>
                        <div class="h3 fw-bold text-danger mb-0"><?= $rejectedCount ?></div>
                    </div>
                </div>
            </a>
        </div>
    </div>

    <!-- Search & Filter Card -->
    <div class="card mb-4 border-0 shadow-sm">
        <div class="card-body">
            <form method="GET" action="<?= base_url('applications/index.php') ?>" class="row g-3 align-items-center">
                <div class="col-md-5">
                    <div class="input-group">
                        <span class="input-group-text bg-light"><i class="bi bi-search"></i></span>
                        <input type="text" name="search" class="form-control" placeholder="Search applicant, email, or job..." value="<?= htmlspecialchars($search) ?>">
                    </div>
                </div>
                <div class="col-md-3">
                    <select name="status" class="form-select">
                        <option value="">All Statuses</option>
                        <option value="Pending" <?= $statusFilter === 'Pending' ? 'selected' : '' ?>>Pending Review</option>
                        <option value="Reviewed" <?= $statusFilter === 'Reviewed' ? 'selected' : '' ?>>Under Review</option>
                        <option value="Accepted" <?= $statusFilter === 'Accepted' ? 'selected' : '' ?>>Accepted</option>
                        <option value="Rejected" <?= $statusFilter === 'Rejected' ? 'selected' : '' ?>>Rejected</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <select name="job_id" class="form-select">
                        <option value="">All Job Postings</option>
                        <?php foreach ($jobListings as $jl): ?>
                            <option value="<?= $jl['id'] ?>" <?= $jobFilter === (int)$jl['id'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($jl['title']) ?> (<?= htmlspecialchars($jl['company']) ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2 d-flex gap-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="bi bi-funnel me-1"></i> Filter
                    </button>
                    <?php if (!empty($search) || !empty($statusFilter) || $jobFilter): ?>
                        <a href="<?= base_url('applications/index.php') ?>" class="btn btn-outline-secondary">
                            Reset
                        </a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>

    <!-- Applications Table Card -->
    <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
        <div class="card-header bg-white border-bottom py-3 px-4 d-flex justify-content-between align-items-center">
            <h5 class="fw-bold mb-0 text-dark">
                <i class="bi bi-people text-primary me-2"></i>Candidates &amp; Applications
            </h5>
            <span class="badge bg-light text-dark border">
                Showing <?= count($applications) ?> results
            </span>
        </div>
        <div class="card-body p-0">
            <?php if (!empty($applications)): ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-4">Applicant</th>
                                <th>Position Applied For</th>
                                <th>Phone</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th class="text-end pe-4">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($applications as $app): ?>
                                <tr>
                                    <td class="ps-4">
                                        <div class="fw-bold text-dark">
                                            <?= htmlspecialchars($app['applicant_name']) ?>
                                        </div>
                                        <div class="small text-muted">
                                            <i class="bi bi-envelope me-1"></i><?= htmlspecialchars($app['applicant_email']) ?>
                                        </div>
                                    </td>
                                    <td>
                                        <a href="<?= base_url('jobs/view.php?id=' . $app['job_id']) ?>" class="fw-semibold text-primary text-decoration-none">
                                            <?= htmlspecialchars($app['job_title']) ?>
                                        </a>
                                        <div class="small text-secondary">
                                            <i class="bi bi-building me-1"></i><?= htmlspecialchars($app['company']) ?>
                                            <span class="badge <?= ($app['job_type'] === 'Job') ? 'badge-type-job' : 'badge-type-internship' ?> ms-1" style="font-size: 0.65rem;">
                                                <?= htmlspecialchars($app['job_type']) ?>
                                            </span>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="small text-muted">
                                            <i class="bi bi-telephone me-1"></i><?= htmlspecialchars($app['phone'] ?: 'N/A') ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="small text-muted">
                                            <?= date('M d, Y', strtotime($app['applied_at'])) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($app['status'] === 'Accepted'): ?>
                                            <span class="badge bg-success px-2 py-1">
                                                <i class="bi bi-check-circle-fill me-1"></i> Accepted
                                            </span>
                                        <?php elseif ($app['status'] === 'Reviewed'): ?>
                                            <span class="badge bg-info text-dark px-2 py-1">
                                                <i class="bi bi-eye-fill me-1"></i> Reviewed
                                            </span>
                                        <?php elseif ($app['status'] === 'Rejected'): ?>
                                            <span class="badge bg-danger px-2 py-1">
                                                <i class="bi bi-x-circle-fill me-1"></i> Rejected
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-warning text-dark px-2 py-1">
                                                <i class="bi bi-clock-history me-1"></i> Pending
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-end pe-4">
                                        <!-- View Details Modal Trigger -->
                                        <button type="button" class="btn btn-outline-primary btn-sm" data-bs-toggle="modal" data-bs-target="#appModal<?= $app['id'] ?>" title="View Application Note">
                                            <i class="bi bi-eye"></i> Details
                                        </button>

                                        <!-- Status Change Dropdown -->
                                        <div class="btn-group">
                                            <button type="button" class="btn btn-outline-secondary btn-sm dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                                                Status
                                            </button>
                                            <ul class="dropdown-menu dropdown-menu-end shadow-sm">
                                                <li><h6 class="dropdown-header">Update Status</h6></li>
                                                <li>
                                                    <form method="POST" action="<?= base_url('applications/index.php') ?>">
                                                        <input type="hidden" name="action" value="update_status">
                                                        <input type="hidden" name="application_id" value="<?= $app['id'] ?>">
                                                        <input type="hidden" name="status" value="Pending">
                                                        <button type="submit" class="dropdown-item <?= $app['status'] === 'Pending' ? 'active' : '' ?>">
                                                            <i class="bi bi-clock text-warning me-2"></i> Pending
                                                        </button>
                                                    </form>
                                                </li>
                                                <li>
                                                    <form method="POST" action="<?= base_url('applications/index.php') ?>">
                                                        <input type="hidden" name="action" value="update_status">
                                                        <input type="hidden" name="application_id" value="<?= $app['id'] ?>">
                                                        <input type="hidden" name="status" value="Reviewed">
                                                        <button type="submit" class="dropdown-item <?= $app['status'] === 'Reviewed' ? 'active' : '' ?>">
                                                            <i class="bi bi-eye text-info me-2"></i> Under Review
                                                        </button>
                                                    </form>
                                                </li>
                                                <li>
                                                    <form method="POST" action="<?= base_url('applications/index.php') ?>">
                                                        <input type="hidden" name="action" value="update_status">
                                                        <input type="hidden" name="application_id" value="<?= $app['id'] ?>">
                                                        <input type="hidden" name="status" value="Accepted">
                                                        <button type="submit" class="dropdown-item <?= $app['status'] === 'Accepted' ? 'active' : '' ?>">
                                                            <i class="bi bi-check-circle text-success me-2"></i> Accepted
                                                        </button>
                                                    </form>
                                                </li>
                                                <li>
                                                    <form method="POST" action="<?= base_url('applications/index.php') ?>">
                                                        <input type="hidden" name="action" value="update_status">
                                                        <input type="hidden" name="application_id" value="<?= $app['id'] ?>">
                                                        <input type="hidden" name="status" value="Rejected">
                                                        <button type="submit" class="dropdown-item <?= $app['status'] === 'Rejected' ? 'active' : '' ?>">
                                                            <i class="bi bi-x-circle text-danger me-2"></i> Rejected
                                                        </button>
                                                    </form>
                                                </li>
                                            </ul>
                                        </div>

                                        <!-- Delete Application -->
                                        <form method="POST" action="<?= base_url('applications/index.php') ?>" class="d-inline" onsubmit="return confirm('Are you sure you want to permanently delete this application record?');">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="application_id" value="<?= $app['id'] ?>">
                                            <button type="submit" class="btn btn-outline-danger btn-sm" title="Delete record">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>

                                <!-- Applicant Detail Modal -->
                                <div class="modal fade" id="appModal<?= $app['id'] ?>" tabindex="-1" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered modal-lg">
                                        <div class="modal-content border-0 shadow">
                                            <div class="modal-header bg-light">
                                                <h5 class="modal-title fw-bold">
                                                    <i class="bi bi-file-earmark-person text-primary me-2"></i>
                                                    Application #<?= $app['id'] ?> - <?= htmlspecialchars($app['applicant_name']) ?>
                                                </h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body p-4">
                                                <div class="row g-3 mb-4">
                                                    <div class="col-md-6">
                                                        <div class="p-3 bg-light rounded-3">
                                                            <div class="text-secondary small text-uppercase fw-semibold mb-1">Applicant Profile</div>
                                                            <div class="fw-bold fs-6"><?= htmlspecialchars($app['applicant_name']) ?></div>
                                                            <div class="text-muted small"><i class="bi bi-envelope me-1"></i><?= htmlspecialchars($app['applicant_email']) ?></div>
                                                            <div class="text-muted small"><i class="bi bi-telephone me-1"></i><?= htmlspecialchars($app['phone'] ?: 'No phone provided') ?></div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="p-3 bg-light rounded-3">
                                                            <div class="text-secondary small text-uppercase fw-semibold mb-1">Vacancy Information</div>
                                                            <div class="fw-bold fs-6"><?= htmlspecialchars($app['job_title']) ?></div>
                                                            <div class="text-secondary small"><i class="bi bi-building me-1"></i><?= htmlspecialchars($app['company']) ?> (<?= htmlspecialchars($app['job_type']) ?>)</div>
                                                            <div class="text-muted small"><i class="bi bi-calendar-event me-1"></i>Applied: <?= date('F d, Y - h:i A', strtotime($app['applied_at'])) ?></div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <?php if (!empty($app['resume_url'])): ?>
                                                    <div class="mb-3 p-3 border rounded-3 bg-white">
                                                        <span class="fw-semibold text-secondary small text-uppercase d-block mb-1">Resume / Portfolio Web Link:</span>
                                                        <a href="<?= htmlspecialchars($app['resume_url']) ?>" target="_blank" rel="noopener noreferrer" class="btn btn-outline-primary btn-sm">
                                                            <i class="bi bi-box-arrow-up-right me-1"></i> Open Resume / Portfolio
                                                        </a>
                                                        <span class="ms-2 text-muted small text-break"><?= htmlspecialchars($app['resume_url']) ?></span>
                                                    </div>
                                                <?php endif; ?>

                                                <div class="mb-3">
                                                    <span class="fw-semibold text-secondary small text-uppercase d-block mb-2">Candidate Cover Statement / Pitch:</span>
                                                    <div class="p-3 bg-light border rounded-3 text-secondary" style="white-space: pre-line; line-height: 1.6;">
                                                        <?= htmlspecialchars($app['cover_note']) ?>
                                                    </div>
                                                </div>

                                                <!-- Inline Status Update Form in Modal -->
                                                <div class="p-3 border rounded-3 bg-light d-flex flex-column flex-sm-row justify-content-between align-items-sm-center gap-2">
                                                    <div>
                                                        <span class="small fw-bold text-dark">Current Status:</span>
                                                        <span class="badge bg-secondary ms-1"><?= htmlspecialchars($app['status']) ?></span>
                                                    </div>
                                                    <form method="POST" action="<?= base_url('applications/index.php') ?>" class="d-flex gap-2 align-items-center">
                                                        <input type="hidden" name="action" value="update_status">
                                                        <input type="hidden" name="application_id" value="<?= $app['id'] ?>">
                                                        <select name="status" class="form-select form-select-sm" style="width: 140px;">
                                                            <option value="Pending" <?= $app['status'] === 'Pending' ? 'selected' : '' ?>>Pending</option>
                                                            <option value="Reviewed" <?= $app['status'] === 'Reviewed' ? 'selected' : '' ?>>Reviewed</option>
                                                            <option value="Accepted" <?= $app['status'] === 'Accepted' ? 'selected' : '' ?>>Accepted</option>
                                                            <option value="Rejected" <?= $app['status'] === 'Rejected' ? 'selected' : '' ?>>Rejected</option>
                                                        </select>
                                                        <button type="submit" class="btn btn-primary btn-sm">Save</button>
                                                    </form>
                                                </div>
                                            </div>
                                            <div class="modal-footer bg-light">
                                                <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="text-center py-5">
                    <i class="bi bi-inbox display-4 text-muted opacity-50 d-block mb-3"></i>
                    <h5 class="fw-bold text-dark">No candidate applications found</h5>
                    <p class="text-muted">No applications match your current search and filter criteria.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include_once __DIR__ . '/../includes/footer.php'; ?>
